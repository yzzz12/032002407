
Page({
  data:{
    username:"",
    school:"",
    major:""
  },
  onLoad:function(options){
    var token=wx.getStorageSync("token")
    wx.request({
      url:'http://119.91.218.4:8000/my/getinfo',
      method: 'GET',
      header: {'content-type':'application/json',
      'Authorization': token            
      },
      success:res=>{
        const obj=res.data
        this.setData(
          {
            username:obj.info.username,
            school:obj.info.school,
            major:obj.info.major
          }
        )
      }
    })
  },

  //退出登录函数
  logout:function() {
 
    wx.removeStorage({
 
      // 小程序文档：本地缓存中指定的 key，还不知道是什么
      key: 'userInfo',
 
      success (res) {
 
        wx.showModal({
 
          title: '提示',
          content: '真的要退出了吗',
          cancelText:'我骗你的',
          confirmText:'是的没错',
          confirmColor:'#000000',
          cancelColor:'#576b95',
          success (res) {
            if (res.confirm) {
              wx.reLaunch({
 
              url: '/pages/course/course',
 
              })
 
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
 
        })
      }
 
    })
  }
 




})