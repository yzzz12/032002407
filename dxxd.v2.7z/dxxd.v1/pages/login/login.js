Page({
  // const token

  data: {
    uesrname:"",
    password:"",
    // token:""
  },
  username:function(e){
    var username = e.detail.value;
    this.setData({username:username});
  },
  password:function(e){
    var password= e.detail.value;
    this.setData({password:password});
  },
  login:function(){
    // console.log(this.data.username)
    // console.log(this.data.password)
    wx.request({
      url:'http://119.91.218.4:8000/api/login',
      method: 'POST',
      // header: {'content-type':'application/json'},
      header: {'content-type':'application/x-www-form-urlencoded'},

      data:{
        username:this.data.username,
        password:this.data.password
      },
      success : function(res){
        // if(res.statusCode==200){
        //           console.log(res.data)

        // }
        // const res=JSON.parse(this.response) 
        // const ob=JSON.parse(res.data) 
        // console.log(ob)

        const obj=res.data
        console.log(obj)
        // const token

        if(obj.status==0){
        //  wx.setStorageSync("token",obj.token)
                 console.log(obj.token)
                // var token=wx.setStorageSync("token")
                wx.setStorage({
                  key:"token",
                  data:obj.token                
                })
                  // var token=wx.getStorageSync("token")
                  // console.log(token)
          wx.switchTab({
            url: '../course/course',
          })
        }
        else if(obj.status==1){
          if(obj.message="用户密码错误"){
            wx.showToast({
              title: '密码错误，请重新确认',
              // icon: 'none',
              // duration: 2000
            })
        }
        else if(obj.message="该用户不存在"){
            wx.showToast({
              title: '用户不存在，请确认您已注册',
              // icon: 'none',
              // duration: 2000
            })
        }
          
        }
      },
      // fail:function(res){
      //   wx.showToast({
      //     title: '系统错误，请稍后重试',
      //     // icon: 'none',
      //     // duration: 2000
      //   })
      // }
    })
  },
})
