// 全局数据共享
// 在这个js文件中专门创建store实例对象
import {observable, action} from 'mobx-miniprogram'

export const store = observable({
  // 数据字段

  // 计算属性

  // action函数 专门修改 store 中的值
  
})