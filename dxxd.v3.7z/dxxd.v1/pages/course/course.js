// pages/course/course.js
import Dialog from '../../miniprogram_npm/@vant/weapp/dialog/dialog'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    activeName: '0',
    show: false,
    course:[],
    courseol:[
      {url:'123456',title:'高数',pic:'../../images/c1.jpg',tags:['数学','考研']},
      {url:'564156',title:'王道考研计算机组成原理王道考研计算机组成原理王道考研计算机组成原理',pic:'../../images/c2.jpg',tags:['考研']},
      {url:'as4656',title:'java',pic:'../../images/c3.jpg',tags:[]}
    ],
    addCourseDate:{
      url:"",
      title:"",
      tags:[]
    },
    collapseActiveName:'1',
    show: false,
    tempTag:"",
    addCourseDate:{
      url:"",
      title:"",
      tags:[]
    }
  },
  onCloseSwiper(event) {
    const { position, instance } = event.detail;
    switch (position) {
      case 'left':
      case 'cell':
        instance.close();
        break;
      case 'right':
        Dialog.confirm({
          message: '确定删除吗？',
        }).then(() => {
          this.data.courseol.splice(instance.data.name,1);
          instance.close();
          this.onLoad();
        }).catch(() => {
          // on cancel
        });
        break;
    }
  },
  onChangeCollapse(event) {
    this.setData({
      collapseActiveName: event.detail,
    });
  },
  onClosePopup() {
    this.setData({ show: false });
  },
  addCourseUrl(e){
    // console.log(e.detail);
    this.setData({
      ['addCourseDate.url']:e.detail
    })
  },
  addCourseTitle(e){
    // console.log(e.detail);
    this.setData({
      ['addCourseDate.title']:e.detail
    })
  },
  showPopup() {
    this.setData({ show: true });
    this.pasteboard();
  },
  addCourseTag(e){
    // console.log(e.detail);
    this.setData({
      tempTag:e.detail
    })
  },
  submitCourseData(){
    this.setData({
      ['addCourseDate.pic']:'../../images/test.jpg',
    })
    this.data.courseol.push(this.data.addCourseDate);
    this.setData({
      tempTag:"",
      addCourseDate:{
        url:"",
        title:"",
        tags:[]
      }
    })
    this.onLoad();
    this.onClosePopup();
  },
  scanCodeEvent: function(){
    var that = this;
    wx.scanCode({
      onlyFromCamera: true,// 只允许从相机扫码
      success(res){
        console.log("扫码成功："+JSON.stringify(res))
  
        // 扫码成功后  在此处理接下来的逻辑
        that.setData({
          scanCode: res.result
        })
      }
    })
  },
  pasteboard: function (e) {
    var th = this;
    wx.getClipboardData({
      success(res) {
        var a = res.data;
        // console.log(a)
        th.setData({
          ['addCourseDate.url']:a
        })
      }
    })
  },
  submitTag(e){
    this.data.addCourseDate.tags.push(this.data.tempTag)
    this.setData({
      ['addCourseDate.tags']:this.data.addCourseDate.tags,
      tempTag:""
    })
  },
  closeTag(e){
    console.log(e);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

    // this.setData({
    //   course:this.data.courseol
    // })
              var token=wx.getStorageSync("token")
              console.log(token)
          wx.request({
          url:'http://119.91.218.4:443/my/getcourse',
          method: 'GET',
          header: {'content-type':'application/json',
          'Authorization': token            
          },
          success:function(res){
          const obj=res.data 
          // const ob=JSON.parse(res.data) 

          console.log(obj)
          // console.log(ob)
          // this.setData(
          // {
          // username:obj.info.username
          // }
          // )
          }
          })    


  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.onLoad();
    wx.stopPullDownRefresh() 
  },
  
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  
})