
Page({
  data:{
    username:"",
    school:"",
    major:""
  },
  onLoad:function(options){
    const token=wx.getStorageSync("token")
    wx.request({
      url:'http://119.91.218.4:443/my/getinfo',
      method: 'GET',
      header: {'content-type':'application/json',
      'Authorization': token            
      },
      success:res=>{
        const obj=res.data
        console.log(obj)
        this.setData(
          {
            username:obj.info.username,
            school:obj.info.school,
            major:obj.info.major
          }
        )
      }
    })
  },

  //退出登录函数
  logout:function() {
    wx.removeStorage({ 
      key: 'token',
      success (res) {
        wx.showModal({
          title: '提示',
          content: '真的要退出了吗',
          cancelText:'我骗你的',
          confirmText:'是的没错',
          confirmColor:'#000000',
          cancelColor:'#576b95',
          success (res) {
            if (res.confirm) {
              wx.reLaunch({
              url: '/pages/login/login',
              })
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      }
    })

  },
 
  onPullDownRefresh() {
    this.onLoad();
    wx.stopPullDownRefresh() 
  },



})