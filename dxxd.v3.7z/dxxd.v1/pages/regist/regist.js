Page({

  data: {
    username:"",
    school:"",
    major:"",
    password:""
  },

  username:function(e){
    var username = e.detail.value;
    this.setData({username:username});
  },
  school:function(e){
    var school = e.detail.value;
    this.setData({school:school});
  },
  major:function(e){
    var major = e.detail.value;
    this.setData({major:major});
  },
  password:function(e){
    var password = e.detail.value;
    this.setData({password:password});
  },
  regist:function(){
    // console.log(this.data.name);
    // console.log(this.data.password);
    wx.request({
      url: 'http://119.91.218.4:443/api/reguser',
      method: 'POST',
      // header: {'content-type':'application/json'},
      header: {'content-type':'application/x-www-form-urlencoded'},

      data:{
        username:this.data.username,
        school:this.data.school,
        major:this.data.major,
        password:this.data.password,    
      },
      success:function(res){
        const obj=res.data
        if(obj.status==0){
          wx.showToast({
            title: '注册成功',
            // icon:'none',
            // duration:2000
          })
          //注册成功后返回登录界面
          wx.navigateTo({
                url: '../login/login',
              })
      }
      else if(obj.status==1){
          if(obj.message="用户名被占用，请更换其它用户名"){
            wx.showToast({
              title: '用户名已存在',
              // icon:'none',
              // duration:2000
            })
          }
          else if(obj.message="注册失败"){
            wx.showToast({
              title: '注册失败，请稍后再试',
              // icon:'none',
              // duration:2000
            })
          }
      }
      },
      fail:function(res){
        wx.showToast({
          title: '系统错误，请稍后重试',
          icon: 'none',
          duration: 2000
        })
      }
    })
  }
})
