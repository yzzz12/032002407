// app.js
App({
  onLaunch: function() {
      //初始化加载，先判断用户登录状态
      if (wx.getStorageSync('token')) {
          wx.switchTab({
              url: 'pages/course/course'
          })
      } else {
          wx.reLaunch({
              url: 'pages/login/login'
          })
      }

  },
  globalData: {

  }
})
